#pragma once
#include "operatie.h"
class Scadere : public operatie
{
public:
    Scadere();
    ~Scadere();
};
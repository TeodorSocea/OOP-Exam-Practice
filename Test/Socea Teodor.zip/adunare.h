#pragma once
#include "operatie.h"
class Adunare : public operatie
{
public:
    Adunare();
    ~Adunare();
};
#pragma once
#include "operatie.h"
class Inmultire : public operatie
{
public:
    Inmultire();
    ~Inmultire();
};
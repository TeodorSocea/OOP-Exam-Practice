#pragma once
#include "operatie.h"
class Impartire : public operatie
{
public:
    Impartire();
    ~Impartire();
};
#pragma once
class operatie
{
public:
    char *nume;
};